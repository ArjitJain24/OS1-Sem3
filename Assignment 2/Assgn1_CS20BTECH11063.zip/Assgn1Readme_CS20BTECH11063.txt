# Operating System Programming Assignment 1
## Tanmay Garg CS20BTECH11063

- There are 3 files in the folder
    - Assgn1Src_CS20BTECH11063.c
    - Assgn1Readme_CS20BTECH11063.txt
    - Assgn1Report_CS20BTECH11063.pdf

- To compile and run the program enter the following commands in terminal or powershell window

```
$ gcc -o final_exec Assgn1Src_CS20BTECH11063.c
$ ./final_exec n
```
- n is the number that you wish to run Collatz Conjecture on

- If n is less than 0 then it will prompt user to input a number greater than 0
- If number of input are not 2 then it will throw an error and exit the program