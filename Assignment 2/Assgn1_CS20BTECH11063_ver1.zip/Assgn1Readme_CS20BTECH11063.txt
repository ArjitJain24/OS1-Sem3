# Operating System Programming Assignment 1
## Tanmay Garg CS20BTECH11063
- There are 3 files in the folder
    - Assgn1Src_CS20BTECH11063.c
    - Assgn1Readme_CS20BTECH11063.txt
    - Assgn1Report_CS20BTECH11063.pdf

- To compile and run the program enter the following commands in terminal or powershell window

```
$ gcc -o final_exec Assgn1Src_CS20BTECH11063.c
$ ./final_exec
```